use
python gen_pattern.py --help

to generate various calibration svg calibration patterns.
