Object Detection using Boosted Features
=======================================

Uses a Waldboost cascade and local binary patterns computed as integral features for 2D object detection.
