Phase Unwrapping
================

OpenCV module that can be used to unwrap two-dimensional phase map.
