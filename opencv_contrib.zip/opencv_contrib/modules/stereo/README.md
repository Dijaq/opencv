Stereo Correspondence with different descriptors
================================================

Stereo matching done with different descriptors: Census / CS-Census / MCT / BRIEF / MV.
